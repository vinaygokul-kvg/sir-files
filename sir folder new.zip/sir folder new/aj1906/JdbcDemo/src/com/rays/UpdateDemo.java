package com.rays;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.mysql.jdbc.Driver;

public class UpdateDemo {

	public static void main(String[] args)throws IOException {
	
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Employee Details for Update:");
		System.out.println("Emp ID:");
		int empid=Integer.parseInt(br.readLine());		
		System.out.println("Emp Age:");
		int empage=Integer.parseInt(br.readLine());
		System.out.println("Emp Salary");
		double empsalary=Integer.parseInt(br.readLine());
		String qry="update employee set empsalary=?,empage=? where empid=?";
		try {
			DriverManager.registerDriver(new Driver());
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cts_demo", "root", "root");
			PreparedStatement ps=con.prepareStatement(qry);
			ps.setDouble(1, empsalary);
			ps.setInt(2, empage);
			ps.setInt(3, empid);
			ps.executeUpdate();
			int count=ps.executeUpdate();
			System.out.println(count+" records updated");
		}catch (Exception e) {
			System.out.println(e);
		}

	}

}
