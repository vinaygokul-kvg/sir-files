package com.rays;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.mysql.jdbc.Driver;

public class RetriveDataDemo {

	public static void main(String[] args) {
		
		String qry="select * from employee";
		try {
			DriverManager.registerDriver(new Driver());
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cts_demo", "root", "root");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(qry);
			System.out.println("id\t name\t age\t sal");
			while(rs.next())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				int age=rs.getInt(3);
				double sal=rs.getDouble(4);						
				System.out.println(id+"\t"+name+"\t"+age+"\t"+sal);
			}
		}catch (Exception e) {
			System.out.println(e);
		}

	}

}
