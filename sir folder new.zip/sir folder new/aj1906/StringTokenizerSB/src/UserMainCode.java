import java.util.StringTokenizer;

class UserMainCode
{
    public static void display(String s)
	{		
		StringTokenizer st=new StringTokenizer(s,",");
		int str_count=st.countTokens();
		String str[]=new String[str_count];
		int i=0;
		while(st.hasMoreTokens())
		{
			str[i]=st.nextToken();
			i++;
		}
		for(String prt:str)
		System.out.println(prt);		

	}
}