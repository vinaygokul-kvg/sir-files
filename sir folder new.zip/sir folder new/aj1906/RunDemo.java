import java.util.*;
import java.io.*;
class RunDemo
 {
	public static void main(String as[])throws Exception
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Welcome to Java World");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Your Name:");
		String name=br.readLine();
		System.out.println("Enter Your room no:");
		int room=Integer.parseInt(br.readLine());
		System.out.println("Your Name:"+name);
		System.out.println("Your Room No:"+room);
	}
 }