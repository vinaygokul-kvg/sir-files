class Employee
	{
		protected long empId=345;
		double empSalary=10000;
		float empTax=9.5f;
		int empDaysOfWork=24;
		void calculateTax()
		{
			float taxRate=10.5f;
			System.out.println("The  Tax  Rate Of The Employee is "+taxRate);
		}
	}
class MainProgram
	{
		public static void main(String as[])
		{
			Employee emp=new Employee();
			System.out.println("The  Id  of the Employee is "+emp.empId);
			System.out.println("The Salary of The Employee is "+emp.empSalary);
			System.out.println("The  Percentage of Tax  The Employee needs to Pay is  "+emp.empTax);
			System.out.println("The  Total  Number  of Working Days  is "+emp.empDaysOfWork );
			emp.calculateTax();
		}
	}