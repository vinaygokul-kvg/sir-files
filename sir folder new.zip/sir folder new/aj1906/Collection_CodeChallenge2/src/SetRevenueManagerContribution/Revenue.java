package SetRevenueManagerContribution;


class Revenue implements Comparable<Revenue>{
    private String revenueCategory;
    private int amount;

    public Revenue(String revenueCategory, int amount) {
		this.revenueCategory = revenueCategory;
		this.amount = amount;
	}
	public Revenue() {
	}
	public String getRevenueCategory() {
		return revenueCategory;
	}
	public void setRevenueCategory(String revenueCategory) {
		this.revenueCategory = revenueCategory;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	@Override
	public int compareTo(Revenue arg0) {
		if(this.amount == arg0.getAmount())
			return 0;
		else if(this.amount > arg0.getAmount()){
			return -1;
		}
		return 1;
	}	
}

