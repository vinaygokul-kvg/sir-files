package ComparableRaiderRanking;

import java.util.Scanner;
import java.util.TreeSet;

public class Main {
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
TreeSet<Ranking> ts=new TreeSet<Ranking>();
System.out.println("Please provide the number of raiders");
int nor=Integer.parseInt(sc.nextLine());
for(int i=0;i<nor;i++)
{
int j=i+1;
System.out.println("Enter the name of the raider "+j);
String rname=sc.nextLine();
System.out.println("Enter the raid points "+j);
long rpoint=Long.parseLong(sc.nextLine());
ts.add(new Ranking(rname,rpoint));
}
System.out.println("Player Details by raid points(High to Low)");
int j=1;
for(Ranking r:ts)
{ 
System.out.println(j+" "+r.getName()+" "+r.getScore());
j++;
}
}
}
