package IntersectionofSets;

import java.util.ArrayList;
import java.util.StringTokenizer;

public class UserMainCode {
	public  void add(String s)
	{
		ArrayList<String> al=new ArrayList<String>();
		al.add(s);
	}
	
	public  void remove(String s)
	{
		ArrayList<String> al=new ArrayList<String>();
		al.remove(s);
	}

}

