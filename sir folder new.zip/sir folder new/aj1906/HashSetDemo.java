import java.util.*;
class HashSetDemo
{
	public static void main(String as[])
	{
		HashSet<String> hSet=new HashSet<String>();
		hSet.add("LONDON");
		hSet.add("NEW YORK");
		hSet.add("PARIS");
		hSet.add("DINDIGUL");
		System.out.println(hSet);
		
		if(hSet.contains("MADURAI"))
		{
			System.out.println("Popular city is New York");
		}
		else
			{
			System.out.println("It doesnot contain Madurai");
		}
	}
}