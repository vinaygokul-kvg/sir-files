import java.util.*;

public class CollectionList1SumAvg{
    public static void main(String[] args){
        Scanner sc=new Scanner (System.in);
        int sum=0;
        float avg=0;
        int n = sc.nextInt();
        int[] arr = new int [n];
        for (int i=0;i<n;i++){
            arr[i]=sc.nextInt();
        }
        for (int i=0;i<n;i++){
            sum = arr[i] + sum;
        }
        avg =(float) sum/n;
        System.out.println(sum);
        System.out.printf("%.2f",avg);
    }
    }

