package com.rays.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.rays.model.Employee;
import com.rays.model.dao.EmployeeDAO;
import com.rays.model.dao.EmployeeDAOImpl;

/**
 * Servlet implementation class ShowAllEmployee
 */
@WebServlet("/ShowAllEmployee.do")
public class ShowAllEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowAllEmployee() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession hs=request.getSession();
		if(null!=hs.getAttribute("id"))
		{
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html");		
		EmployeeDAO empdao=new EmployeeDAOImpl();
		List<Employee> emplist=empdao.getAllEmployee();
		request.setAttribute("emplist", emplist);
		request.getRequestDispatcher("showall.jsp").include(request, response);
		}else
		{
			request.getRequestDispatcher("timeout.jsp").forward(request, response);
		}
		/*pw.println("<table border=1>");
		pw.println("<tr><td>Emp ID</td><td>Emp Name</td><td>Emp Age</td><td>Emp Salary</td></tr>");
		for(Employee emp:emplist)
		{
			pw.println("<tr>");
			pw.println("<td>"+emp.getEmpid()+"</td>");
			pw.println("<td>"+emp.getEmpname()+"</td>");
			pw.println("<td>"+emp.getEmpage()+"</td>");
			pw.println("<td>"+emp.getEmpsalary()+"</td>");
			pw.println("</tr>");
		}
		pw.println("</table>");*/
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
