package com.cts.dao;

@FunctionalInterface
public interface Oneable {

	public void test();
}
