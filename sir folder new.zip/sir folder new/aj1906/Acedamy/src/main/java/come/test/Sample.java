package come.test;

public class Sample {
	/*@Autowired
	Test tt;
	public void get() {
		tt.test();
	}*/
/*	Test t1;
	public Sample(Test t1) {
		this.t1=t1;
	}
	void doIt() {
		t1.test();
	}*/
	Test t1;

	public void setT1(Test t1) {
		this.t1 = t1;
	}
	public void doIt() {
		t1.test();
	}
	
}
