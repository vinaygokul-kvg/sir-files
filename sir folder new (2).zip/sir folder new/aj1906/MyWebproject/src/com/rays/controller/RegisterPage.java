package com.rays.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Driver;

/**
 * Servlet implementation class RegisterPage
 */
@WebServlet("/RegisterPage")
public class RegisterPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterPage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw=response.getWriter();
		String aname=request.getParameter("aname");
		int age=Integer.parseInt(request.getParameter("age"));
		double salary=Double.parseDouble(request.getParameter("salary"));
		/*pw.println("<font color=green size=20>Associates Name:"+aname+"<br>");
		pw.print("Age:"+age+"<br>");
		pw.print("Salary:"+salary+"</font>");*/
		try {
			DriverManager.registerDriver(new Driver());
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cts_demo","root","root");
			PreparedStatement ps=con.prepareStatement("insert into associatesdetails values(?,?,?)");
			ps.setString(1, aname);
			ps.setInt(2, age);
			ps.setDouble(3, salary);
			ps.execute();
			pw.println("<span style=color:green>Registered Successfully...</span>");
			//pw.println("<a href='register.html'>Register More...</a>");
			RequestDispatcher rd=request.getRequestDispatcher("register.html");
					//rd.forward(request, response);
			rd.include(request, response);
		} catch (Exception e) {
			System.out.println("Error in Register :"+e);
			pw.println("<span style=color:red>Registered Failed"+e.getMessage()+"</span>");			
			RequestDispatcher rd=request.getRequestDispatcher("register.html");
			rd.include(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
