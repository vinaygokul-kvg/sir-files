import java.io.*;
class SwitchDemo1
{
	public static void main(String as[])throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Your choice");
		String color=br.readLine();
		switch(color)
		{
			case "RED":
			case "red":
				System.out.println("Stop");
				break;
			case "GREEN":
				System.out.println("Go");
				break;
			default:
				System.out.println("Wrong Entry....");
				break;
		}	   		
	}
}