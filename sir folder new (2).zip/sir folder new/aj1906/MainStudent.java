class StudentRecord
{
	StudentRecord()
	{
		System.out.println("From Default Constructor");
	}
	void printDetails()
	{
		System.out.println("From Print Details Method");
	}
}
class MainStudent
{
	public static void main(String as[])
	{
		StudentRecord sr=new StudentRecord();
		sr.printDetails();
	}
}
