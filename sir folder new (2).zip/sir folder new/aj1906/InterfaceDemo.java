interface IVehicle
{	
	void drive();
	void turnLeft();
	void brake();
}
interface IPublicTransport
{
	final int noOfPeople=2500;
	void getNumberOfpeople();
}
class MotorisedVehicle
{
	void checkMotor()
	{
		System.out.println("The motor of the vehicle is in good condition");
	}	
}
class Car extends MotorisedVehicle implements IVehicle
{
	public void drive()
	{
		System.out.println("Car in Drive Mode");
	}
	public void turnLeft()
	{
		System.out.println("Car going to Turn Left");
	}
	public void brake()
	{
		System.out.println("Car in Brake Mode");
	}
}
class Train implements IVehicle,IPublicTransport
{
	public void drive()
	{
		System.out.println("Train in Drive Mode");
	}
	public void turnLeft()
	{
		System.out.println("Train going on Left line");
	}
	public void brake()
	{
		System.out.println("Train in Central Station");
	}	
	public void getNumberOfpeople()
	{
		//noOfPeople=3500;  cannot assign values to final(constant) variable
		System.out.println("No of Peoples in train: "+noOfPeople);
	}
}
class InterfaceDemo
{
	public static void main(String as[])
	{
		IVehicle I=new Car();  // Implicit Casting
	Car C=new Car();
	C.drive();
	C.turnLeft();
	C.checkMotor();
	C.brake();
	
	Train T=new Train();
	T.drive();
	T.turnLeft();
	T.getNumberOfpeople();
	T.brake();	
	}
}
