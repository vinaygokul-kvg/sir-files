package ComparableRaiderRanking;

public class Ranking implements Comparable<Ranking>{

String name;
Long score;
public Ranking(String name, Long score) {
super();
this.name = name;
this.score = score;
}

public String getName() {
return name;
}

public void setName(String name) {
this.name = name;
}

public Long getScore() {
return score;
}

public void setScore(Long score) {
this.score = score;
}

@Override
public int compareTo(Ranking r) {
Ranking r1=this;
if(r1.getScore()<r.getScore())
return +1;
else if(r1.getScore()>r.getScore())
return -1;
else
return 0;
}

}

