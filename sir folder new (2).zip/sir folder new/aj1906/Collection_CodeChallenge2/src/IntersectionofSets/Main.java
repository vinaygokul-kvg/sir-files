package IntersectionofSets;

import java.awt.List;
import java.util.*;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		HashSet<String> hs1 = new HashSet<String>();
		HashSet<String> hs2 = new HashSet<String>();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of best raiders in season 3");
		int n = Integer.parseInt(sc.nextLine());
		
		System.out.println("Enter the name of players");
		for(int i=0;i<n;i++){
			hs1.add(sc.nextLine());
		}
		
		System.out.println("Enter the number of best raiders in season 4");
		int m = Integer.parseInt(sc.nextLine());
		
		System.out.println("Enter the name of players");
		for(int i=0;i<m;i++){
			hs2.add(sc.nextLine());
		}
		
		System.out.println("Player Set 1");
		for(String s : hs1){
			System.out.println(s);
		}
		
		System.out.println("Player Set 2");
		for(String s : hs2){
			System.out.println(s);
		}
		
		System.out.println("Intersection");
		hs1.retainAll(hs2);
		for(String s : hs1){
			System.out.println(s);
		}
	
		
}

}
