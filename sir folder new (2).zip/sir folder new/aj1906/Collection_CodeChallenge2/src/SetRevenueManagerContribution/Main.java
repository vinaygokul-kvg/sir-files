package SetRevenueManagerContribution;

import java.io.*;
import java.io.ObjectInputStream.GetField;
import java.util.TreeSet;
public class Main {
public static void main(String args[]) throws IOException {
    TreeSet <Revenue> tree = new TreeSet<>();
    String choice = "no";
    BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
	 String revenueCategory;
	 int amount;
	 do
	 {
		 System.out.println("Enter revenue category");
		 revenueCategory = bf.readLine();
		 System.out.println("Enter revenue amount");
		 amount = Integer.parseInt(bf.readLine());
		 System.out.println("Do you want to continue(yes/no):");
		 choice = bf.readLine();
		 tree.add(new Revenue(revenueCategory, amount));
	 }while(choice.equalsIgnoreCase("yes"));
	 System.out.println("Top spending categories");
	 System.out.println(String.format("%-15s%-15s","Category", "Amount"));
	 int tot =0;
	 for(Revenue t : tree)
	 {
		 System.out.println(String.format("%-15s%-15s",t.getRevenueCategory(),t.getAmount()));
		 tot = tot +t.getAmount();
	 }
	 System.out.println("Total amount earned: "+tot);
	 System.out.println(String.format("%-15s%-15s","Category", "Contribution"));
	 for(Revenue t : tree)
	 {	float contribut=((float)t.getAmount()/(float)tot)*100;
		 System.out.println(String.format("%-15s%.2f          ",t.getRevenueCategory(),contribut));
		 //System.out.println();
	 }
}
	
}

