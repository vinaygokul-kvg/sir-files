import java.io.*;
class ArrDemo1
{
	public static void main(String as[])throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int[] reg_no=new int[5];
		int []reg_no1[]=new int[5][5];
		String stu_name[]=new String[5];
		for(int i=0;i<reg_no.length;i++)
			{
				reg_no[i]=Integer.parseInt(br.readLine());
				//stu_name[i]=br.readLine();
			}
		   
		/*for(int i=0;i<reg_no.length;i++)
			{
				System.out.println("Reg No:"+reg_no[i]+"\t Student Name:"+stu_name[i]);
			}*/
	   
		for(int pr:reg_no)
		{
			System.out.println(pr);
		}
	}
}