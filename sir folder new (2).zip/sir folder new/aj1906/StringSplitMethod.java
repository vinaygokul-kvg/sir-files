class StringSplitMethod
{
	public static void main(String as[])
	{
		String msg1="java is a platform java independent java language";
		String msg2="rays.rmr@gmail.com";
		String str[]=msg1.split(" ");
		for(String p:str)
			System.out.println(p);
		
		String str1[]=msg2.split("@");
		for(String p:str1)
			System.out.println(p);
	}
}