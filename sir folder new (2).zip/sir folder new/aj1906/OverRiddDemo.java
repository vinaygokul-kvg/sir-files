class Parent
{	
	void parentMet()
	{
		System.out.println("In Parent Method");
	}
}
class Child extends Parent
{		
	void childMet()
	{		
		System.out.println("In Child Method");
	}
	void parentMet()
	{
		System.out.println("In Parent Method from Child");
	}
}
class OverRiddDemo
{
	public static void main(String as[])
	{
		Parent C=new Child();		
		//C.childMet();
		C.parentMet();
	}
}