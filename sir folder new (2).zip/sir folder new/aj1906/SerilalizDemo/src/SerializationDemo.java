import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializationDemo {

	public static void main(String[] args)throws IOException, ClassNotFoundException {
		
		Employee emp=new Employee(1001, "Raffic", 45000);
		System.out.println("Employee Detail before Serialization :"+emp);
		FileOutputStream fos=new FileOutputStream("d:\\employee.txt");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(emp);
		oos.close();
		
		Employee emp_seri;
		FileInputStream fis=new FileInputStream("d:\\employee.txt");
		ObjectInputStream ois=new ObjectInputStream(fis);
		emp_seri=(Employee)ois.readObject();
		ois.close();
		System.out.println("Employee Detail after Serialization :"+emp_seri);
		
		
	}

}
