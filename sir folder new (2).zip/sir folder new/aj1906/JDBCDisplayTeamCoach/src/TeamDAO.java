

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;


public class TeamDAO {

	
	public List<Team> listTeams(String teamName) throws SQLException
    {

            Connection con = null;
            List<Team> al=new ArrayList<Team>();
            ResourceBundle rb = ResourceBundle.getBundle("mysql");
            String url = rb.getString("db.url");
            String user = rb.getString("db.username");
            String pass = rb.getString("db.password");

                    try {
                        Class.forName("com.mysql.jdbc.Driver");
                    } catch (ClassNotFoundException ex) {
                        Logger.getLogger(TeamDAO.class.getName()).log(Level.SEVERE, null, ex);
                    }
            con = DriverManager.getConnection(url,user,pass);
        
            PreparedStatement ps=con.prepareStatement("select * from team where name=? ");
            ps.setString(1, teamName);
            ResultSet rs=ps.executeQuery();
            while(rs.next()) {
            	al.add(new Team(rs.getString(2),rs.getString(3)));
            }

            return al;

 }
}
