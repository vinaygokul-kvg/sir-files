package com.rays.model.dao;

import java.util.List;

import com.rays.model.Employee;

public interface EmployeeDAO {
	
	public int saveEmployee(Employee emp);
	public int updateEmployee(Employee emp);
	public List<Employee> getAllEmployee();
	public int deleteEmployee(int empid);
	public int getByEmployeeId(int empid);

}
