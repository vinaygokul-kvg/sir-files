package com.rays;
class Sub extends Thread
{
	public void run()
	{
		System.out.println("Start");
	}
}
public class TDemo{	
	public static void main(String[] args) {
		Thread t=new Sub();
		t.start();
		t.start();
	}
}
