import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.mysql.jdbc.Driver;

public class NameSortDemo {

	static Connection con;
	public static void main(String[] args) {
		connectDataBase();
		sortEmployee();		
	}
	
	static void connectDataBase()
	{
		try {
			DriverManager.registerDriver(new Driver());
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cts_demo", "root", "root");
		} catch (Exception e) {
			System.out.println("Error in connect DB :"+e);
		}
	}
	
	static void sortEmployee()
	{
		try {
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select empname,empsalary from employee order by empname");
			while(rs.next())
			{
				System.out.println("Emp Name:"+rs.getString(1)+"\t Emp Salary"+rs.getDouble(2));
			}
		}catch (Exception e) {
			System.out.println("Error in sortEmployee :"+e);
		}
	}
}
