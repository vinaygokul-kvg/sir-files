class StaticExample
{
	int a;
	static int b;
	void printValue()
	{
		System.out.println("a="+a+"\t b="+b);
	}
}