class StudentDetails
{
	int regNo;
	StudentDetails()
	{		
		this(1001);
		System.out.println("From Default Constructor");		
	}
	StudentDetails(int regNo)
	{
		this.regNo=regNo;
		System.out.println("From Parameter Constructor");
		this.printDetails();
	}
	void printDetails()
	{
		System.out.println("Reg Number: "+regNo);		
	}
}
class ThisDemo
{
	public static void main(String as[])
	{
		StudentDetails sd=new StudentDetails();		
	}
}
