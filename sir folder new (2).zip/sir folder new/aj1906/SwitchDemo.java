import java.io.*;
class SwitchDemo
{
	public static void main(String as[])throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Your choice");
		int choice=Integer.parseInt(br.readLine());
		switch(choice)
		{
			case 1:
				System.out.println("You selected ECE");
				break;
			case 2:
				System.out.println("You selected CSE");
				break;
			default:
				System.out.println("Wrong Entry....");
				break;
		}	   		
	}
}