import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class MapUtils
{
	// Generic function to construct a new TreeMap from HashMap
	public static <K,V> Map<K,V> getTreeMap(Map<K,V> hashMap)
	{
		Set<Map.Entry<K, V>> set=hashMap.entrySet();
		Stream<Map.Entry<K, V>> str=set.stream();		
		Map<K, V> treeMap1=str.collect(Collectors.toMap(Map.Entry::getKey,
				Map.Entry::getValue,
				(oldValue, newValue) -> newValue,
				TreeMap::new));
		
		/*Map<K, V> treeMap = hashMap.entrySet()
								.stream()
								.collect(Collectors.toMap(Map.Entry::getKey,
											Map.Entry::getValue,
											(oldValue, newValue) -> newValue,
											TreeMap::new));*/

		return treeMap1;
	}

	// Program to convert HashMap to TreeMap in Java 8
	public static void main(String args[])
	{
		Map<String, String> hashMap = new HashMap<>();

		hashMap.put("RED", "#FF0000");
		hashMap.put("BLUE", "#0000FF");
		hashMap.put("GREEN", "#008000");

		// construct a new TreeMap from HashMap
		Map<String, String> treeMap = getTreeMap(hashMap);
		System.out.println(treeMap);
	}
}