package come.test;

public class Test {
	public void test() {
		System.out.println("Welcome IOC Demo");
	}
}
