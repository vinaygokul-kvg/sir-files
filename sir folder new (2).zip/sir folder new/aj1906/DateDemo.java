import java.util.*;

public class DateDemo {

   public static void main(String args[]) {
      Date dNow = new Date( );
      
      System.out.println("Current Date : "+dNow);      
   }
}