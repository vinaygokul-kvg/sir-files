package com.cts.dao;

public class FunctionalDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Oneable o=()->System.out.println("Hi fun");
		o.test();
		
	}

}
