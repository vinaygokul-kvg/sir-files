import java.util.*;
class ArrayListDemo
{
	public static void main(String as[])
	{
		ArrayList aList=new ArrayList();
		aList.add(123);
		aList.add("CTS");
		aList.add(3.14);
		aList.add(true);
		aList.add('R');
		
		System.out.println(aList);
		
		Iterator itr=aList.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
	}
}